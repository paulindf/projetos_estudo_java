CREATE TABLE pessoa (
    codigo BIGINT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(200) NOT NULL,
    endereco_logradouro VARCHAR(200) NOT NULL,
    endereco_numero VARCHAR(10) NOT NULL,
    endereco_complemento VARCHAR(50) NULL,
    endereco_bairro VARCHAR(80) NULL,
    endereco_cep VARCHAR(9) NOT NULL,
    endereco_cidade VARCHAR(80) NOT NULL,
    endereco_estado VARCHAR(2) NOT NULL,
    ativo BIT NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8;